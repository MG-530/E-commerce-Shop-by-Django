# E-Commerce Database: Core Entities and Attributes

This document identifies and describes the core entities and attributes for an e-commerce database system based on comprehensive research.

## 1. Customer

The Customer entity represents users who create accounts to place orders on the e-commerce platform.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| customer_id | integer | Primary key, unique identifier for each customer |
| first_name | string | Customer's first name |
| last_name | string | Customer's last name |
| email | string | Customer's email address, used for login and communication |
| password | string | Encrypted password for account security |
| address | string | Customer's primary address |
| phone_number | string | Customer's contact phone number |

## 2. Product

The Product entity represents items available for purchase on the platform.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| product_id | integer | Primary key, unique identifier for each product |
| SKU | string | Stock Keeping Unit, a unique code for inventory management |
| description | string | Detailed description of the product |
| price | decimal | Current selling price of the product |
| stock | integer | Current quantity available in inventory |

## 3. Category

The Category entity represents the classification system for products.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| category_id | integer | Primary key, unique identifier for each category |
| name | string | Name of the category |

## 4. Order

The Order entity represents purchase transactions made by customers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| order_id | integer | Primary key, unique identifier for each order |
| order_date | date/time | Date and time when the order was placed |
| total_price | decimal | Total amount of the order |

## 5. Order_Item

The Order_Item entity represents individual products within an order.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| order_item_id | integer | Primary key, unique identifier for each order item |
| quantity | integer | Number of units of the product ordered |
| price | decimal | Price of the product at the time of purchase |

## 6. Payment

The Payment entity stores information about financial transactions related to orders.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| payment_id | integer | Primary key, unique identifier for each payment |
| payment_date | date | Date when the payment was processed |
| payment_method | string | Method used for payment (credit card, PayPal, etc.) |
| amount | decimal | Amount paid |

## 7. Shipment

The Shipment entity stores information about the delivery of orders.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| shipment_id | integer | Primary key, unique identifier for each shipment |
| shipment_date | date | Date when the order was shipped |
| address | string | Shipping address |
| city | string | City for shipping |
| state | string | State/province for shipping |
| country | string | Country for shipping |
| zip_code | string | Postal/ZIP code for shipping |

## 8. Cart

The Cart entity represents the customer's temporary storage for products before purchase.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| cart_id | integer | Primary key, unique identifier for each cart |
| quantity | integer | Number of units of a product in the cart |

## 9. Wishlist

The Wishlist entity represents products that customers have saved for future consideration.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| wishlist_id | integer | Primary key, unique identifier for each wishlist item |
