#!/usr/bin/env python3

import os

# Create a DOT file for Graphviz to generate the enhanced ER diagram with multi-seller capability
dot_content = '''
digraph Multi_Seller_E_Commerce_ER_Diagram {
    graph [pad="0.5", nodesep="0.5", ranksep="2"];
    node [shape=record, fontsize=10, fontname="Arial", margin="0.07,0.05", penwidth=1.0];
    edge [fontname="Arial", fontsize=9, penwidth=1.0, arrowsize=0.7];
    
    // User and Authentication Entities
    User [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>User</b></td></tr>
            <tr><td align="left" port="user_id">PK: user_id (INT)</td></tr>
            <tr><td align="left">email (VARCHAR(100))</td></tr>
            <tr><td align="left">password (VARCHAR(255))</td></tr>
            <tr><td align="left">first_name (VARCHAR(50))</td></tr>
            <tr><td align="left">last_name (VARCHAR(50))</td></tr>
            <tr><td align="left">phone_number (VARCHAR(20))</td></tr>
            <tr><td align="left" port="role">role (VARCHAR(20))</td></tr>
            <tr><td align="left" port="is_seller">is_seller (BOOLEAN)</td></tr>
            <tr><td align="left" port="seller_id">seller_id (INT)</td></tr>
            <tr><td align="left">account_status (VARCHAR(20))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Customer [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Customer</b></td></tr>
            <tr><td align="left" port="customer_id">PK: customer_id (INT)</td></tr>
            <tr><td align="left" port="user_id">FK: user_id (INT)</td></tr>
            <tr><td align="left">address (VARCHAR(255))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    // Seller Entities
    Seller [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller</b></td></tr>
            <tr><td align="left" port="seller_id">PK: seller_id (INT)</td></tr>
            <tr><td align="left" port="user_id">FK: user_id (INT)</td></tr>
            <tr><td align="left">company_name (VARCHAR(100))</td></tr>
            <tr><td align="left">description (TEXT)</td></tr>
            <tr><td align="left">logo_url (VARCHAR(255))</td></tr>
            <tr><td align="left">banner_url (VARCHAR(255))</td></tr>
            <tr><td align="left">website_url (VARCHAR(255))</td></tr>
            <tr><td align="left">tax_id (VARCHAR(50))</td></tr>
            <tr><td align="left">registration_date (DATETIME)</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">commission_rate (DECIMAL(5,2))</td></tr>
            <tr><td align="left">payout_method (VARCHAR(50))</td></tr>
            <tr><td align="left">average_rating (DECIMAL(3,2))</td></tr>
            <tr><td align="left">total_sales (DECIMAL(12,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Rating [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Rating</b></td></tr>
            <tr><td align="left" port="rating_id">PK: rating_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left">rating (DECIMAL(3,2))</td></tr>
            <tr><td align="left">review (TEXT)</td></tr>
            <tr><td align="left">communication_score (DECIMAL(3,2))</td></tr>
            <tr><td align="left">shipping_score (DECIMAL(3,2))</td></tr>
            <tr><td align="left">accuracy_score (DECIMAL(3,2))</td></tr>
            <tr><td align="left">rating_date (DATETIME)</td></tr>
            <tr><td align="left">is_verified_purchase (BOOLEAN)</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Payout [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Payout</b></td></tr>
            <tr><td align="left" port="payout_id">PK: payout_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left">amount (DECIMAL(12,2))</td></tr>
            <tr><td align="left">currency (VARCHAR(3))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">payout_date (DATETIME)</td></tr>
            <tr><td align="left">payout_method (VARCHAR(50))</td></tr>
            <tr><td align="left">transaction_id (VARCHAR(100))</td></tr>
            <tr><td align="left">payout_period_start (DATETIME)</td></tr>
            <tr><td align="left">payout_period_end (DATETIME)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Balance [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Balance</b></td></tr>
            <tr><td align="left" port="balance_id">PK: balance_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left">available_balance (DECIMAL(12,2))</td></tr>
            <tr><td align="left">pending_balance (DECIMAL(12,2))</td></tr>
            <tr><td align="left">currency (VARCHAR(3))</td></tr>
            <tr><td align="left">last_payout_date (DATETIME)</td></tr>
            <tr><td align="left">total_earnings (DECIMAL(12,2))</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Policy [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Policy</b></td></tr>
            <tr><td align="left" port="policy_id">PK: policy_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left">policy_type (VARCHAR(50))</td></tr>
            <tr><td align="left">policy_content (TEXT)</td></tr>
            <tr><td align="left">is_active (BOOLEAN)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    // Product Entities
    Product [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Product</b></td></tr>
            <tr><td align="left" port="product_id">PK: product_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left" port="category_id">FK: category_id (INT)</td></tr>
            <tr><td align="left">SKU (VARCHAR(50))</td></tr>
            <tr><td align="left">name (VARCHAR(100))</td></tr>
            <tr><td align="left">description (TEXT)</td></tr>
            <tr><td align="left">price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">stock (INT)</td></tr>
            <tr><td align="left">image_url (VARCHAR(255))</td></tr>
            <tr><td align="left">approval_status (VARCHAR(20))</td></tr>
            <tr><td align="left">commission_rate (DECIMAL(5,2))</td></tr>
            <tr><td align="left">condition (VARCHAR(50))</td></tr>
            <tr><td align="left">handling_time (INT)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Category [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Category</b></td></tr>
            <tr><td align="left" port="category_id">PK: category_id (INT)</td></tr>
            <tr><td align="left">name (VARCHAR(50))</td></tr>
            <tr><td align="left">description (VARCHAR(255))</td></tr>
            <tr><td align="left" port="parent_id">FK: parent_id (INT)</td></tr>
            <tr><td align="left">commission_rate (DECIMAL(5,2))</td></tr>
            <tr><td align="left">requires_approval (BOOLEAN)</td></tr>
            <tr><td align="left">seller_count (INT)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Category [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Category</b></td></tr>
            <tr><td align="left" port="seller_category_id">PK: seller_category_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left" port="category_id">FK: category_id (INT)</td></tr>
            <tr><td align="left">is_primary (BOOLEAN)</td></tr>
            <tr><td align="left">commission_rate (DECIMAL(5,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    // Order Entities
    Order [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Order</b></td></tr>
            <tr><td align="left" port="order_id">PK: order_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left">order_date (DATETIME)</td></tr>
            <tr><td align="left">total_price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">shipping_address (VARCHAR(255))</td></tr>
            <tr><td align="left">billing_address (VARCHAR(255))</td></tr>
            <tr><td align="left">is_multi_seller (BOOLEAN)</td></tr>
            <tr><td align="left">seller_count (INT)</td></tr>
            <tr><td align="left">platform_fee (DECIMAL(10,2))</td></tr>
            <tr><td align="left">total_commission (DECIMAL(10,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Seller_Order [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="#FFD700"><b>Seller_Order</b></td></tr>
            <tr><td align="left" port="seller_order_id">PK: seller_order_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left">subtotal (DECIMAL(10,2))</td></tr>
            <tr><td align="left">shipping_fee (DECIMAL(10,2))</td></tr>
            <tr><td align="left">tax (DECIMAL(10,2))</td></tr>
            <tr><td align="left">commission_amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">seller_payout_amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">tracking_number (VARCHAR(100))</td></tr>
            <tr><td align="left">carrier (VARCHAR(50))</td></tr>
            <tr><td align="left">fulfillment_date (DATETIME)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Order_Item [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Order_Item</b></td></tr>
            <tr><td align="left" port="order_item_id">PK: order_item_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left" port="product_id">FK: product_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left" port="seller_order_id">FK: seller_order_id (INT)</td></tr>
            <tr><td align="left">quantity (INT)</td></tr>
            <tr><td align="left">price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">commission_rate (DECIMAL(5,2))</td></tr>
            <tr><td align="left">commission_amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">seller_amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">item_status (VARCHAR(20))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
        </table>
    >];
    
    Payment [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Payment</b></td></tr>
            <tr><td align="left" port="payment_id">PK: payment_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left">payment_date (DATETIME)</td></tr>
            <tr><td align="left">payment_method (VARCHAR(50))</td></tr>
            <tr><td align="left">payment_status (VARCHAR(20))</td></tr>
            <tr><td align="left">amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">is_multi_seller (BOOLEAN)</td></tr>
            <tr><td align="left">platform_fee (DECIMAL(10,2))</td></tr>
            <tr><td align="left">total_commission (DECIMAL(10,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Shipment [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Shipment</b></td></tr>
            <tr><td align="left" port="shipment_id">PK: shipment_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left" port="seller_id">FK: seller_id (INT)</td></tr>
            <tr><td align="left" port="seller_order_id">FK: seller_order_id (INT)</td></tr>
            <tr><td align="left">shipment_date (DATETIME)</td></tr>
            <tr><td align="left">carrier (VARCHAR(50))</td></tr>
            <tr><td align="left">tracking_number (VARCHAR(100))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">fulfillment_type (VARCHAR(50))</td></tr>
            <tr><td align="left">shipping_cost (DECIMAL(10,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    // Cart Entities
    Cart [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Cart</b></td></tr>
            <tr><td align="left" port="cart_id">PK: cart_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left">is_multi_seller (BOOLEAN)</td></tr>
            <tr><td align="left">seller_count (INT)</td></tr>
            <tr><td align="left">estimated_shipping (DECIMAL(10,2))</td></tr>
            <tr><td align="left">estimated_tax (DECIMAL(10,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
 
(Content truncated due to size limit. Use line ranges to read in chunks)