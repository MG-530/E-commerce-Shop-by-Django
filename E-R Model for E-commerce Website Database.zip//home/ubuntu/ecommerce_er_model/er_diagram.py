#!/usr/bin/env python3

import os

# Create a DOT file for Graphviz to generate the ER diagram
dot_content = '''
digraph E_Commerce_ER_Diagram {
    graph [pad="0.5", nodesep="0.5", ranksep="2"];
    node [shape=record, fontsize=10, fontname="Arial", margin="0.07,0.05", penwidth=1.0];
    edge [fontname="Arial", fontsize=9, penwidth=1.0, arrowsize=0.7];
    
    // Define entity nodes with attributes
    Customer [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Customer</b></td></tr>
            <tr><td align="left" port="customer_id">PK: customer_id (INT)</td></tr>
            <tr><td align="left">first_name (VARCHAR(50))</td></tr>
            <tr><td align="left">last_name (VARCHAR(50))</td></tr>
            <tr><td align="left">email (VARCHAR(100))</td></tr>
            <tr><td align="left">password (VARCHAR(255))</td></tr>
            <tr><td align="left">address (VARCHAR(255))</td></tr>
            <tr><td align="left">phone_number (VARCHAR(20))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Product [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Product</b></td></tr>
            <tr><td align="left" port="product_id">PK: product_id (INT)</td></tr>
            <tr><td align="left" port="category_id">FK: category_id (INT)</td></tr>
            <tr><td align="left">SKU (VARCHAR(50))</td></tr>
            <tr><td align="left">name (VARCHAR(100))</td></tr>
            <tr><td align="left">description (TEXT)</td></tr>
            <tr><td align="left">price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">stock (INT)</td></tr>
            <tr><td align="left">image_url (VARCHAR(255))</td></tr>
            <tr><td align="left">weight (DECIMAL(8,2))</td></tr>
            <tr><td align="left">dimensions (VARCHAR(50))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Category [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Category</b></td></tr>
            <tr><td align="left" port="category_id">PK: category_id (INT)</td></tr>
            <tr><td align="left">name (VARCHAR(50))</td></tr>
            <tr><td align="left">description (VARCHAR(255))</td></tr>
            <tr><td align="left" port="parent_id">FK: parent_id (INT)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Order [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Order</b></td></tr>
            <tr><td align="left" port="order_id">PK: order_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left">order_date (DATETIME)</td></tr>
            <tr><td align="left">total_price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">shipping_address (VARCHAR(255))</td></tr>
            <tr><td align="left">billing_address (VARCHAR(255))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Order_Item [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Order_Item</b></td></tr>
            <tr><td align="left" port="order_item_id">PK: order_item_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left" port="product_id">FK: product_id (INT)</td></tr>
            <tr><td align="left">quantity (INT)</td></tr>
            <tr><td align="left">price (DECIMAL(10,2))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
        </table>
    >];
    
    Payment [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Payment</b></td></tr>
            <tr><td align="left" port="payment_id">PK: payment_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left">payment_date (DATETIME)</td></tr>
            <tr><td align="left">payment_method (VARCHAR(50))</td></tr>
            <tr><td align="left">payment_status (VARCHAR(20))</td></tr>
            <tr><td align="left">amount (DECIMAL(10,2))</td></tr>
            <tr><td align="left">transaction_id (VARCHAR(100))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Shipment [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Shipment</b></td></tr>
            <tr><td align="left" port="shipment_id">PK: shipment_id (INT)</td></tr>
            <tr><td align="left" port="order_id">FK: order_id (INT)</td></tr>
            <tr><td align="left">shipment_date (DATETIME)</td></tr>
            <tr><td align="left">carrier (VARCHAR(50))</td></tr>
            <tr><td align="left">tracking_number (VARCHAR(100))</td></tr>
            <tr><td align="left">status (VARCHAR(20))</td></tr>
            <tr><td align="left">address (VARCHAR(255))</td></tr>
            <tr><td align="left">city (VARCHAR(50))</td></tr>
            <tr><td align="left">state (VARCHAR(50))</td></tr>
            <tr><td align="left">country (VARCHAR(50))</td></tr>
            <tr><td align="left">zip_code (VARCHAR(20))</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Cart [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Cart</b></td></tr>
            <tr><td align="left" port="cart_id">PK: cart_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Cart_Item [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Cart_Item</b></td></tr>
            <tr><td align="left" port="cart_item_id">PK: cart_item_id (INT)</td></tr>
            <tr><td align="left" port="cart_id">FK: cart_id (INT)</td></tr>
            <tr><td align="left" port="product_id">FK: product_id (INT)</td></tr>
            <tr><td align="left">quantity (INT)</td></tr>
            <tr><td align="left">added_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Wishlist [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Wishlist</b></td></tr>
            <tr><td align="left" port="wishlist_id">PK: wishlist_id (INT)</td></tr>
            <tr><td align="left" port="customer_id">FK: customer_id (INT)</td></tr>
            <tr><td align="left">created_at (DATETIME)</td></tr>
            <tr><td align="left">updated_at (DATETIME)</td></tr>
        </table>
    >];
    
    Wishlist_Item [label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="4">
            <tr><td bgcolor="lightblue"><b>Wishlist_Item</b></td></tr>
            <tr><td align="left" port="wishlist_item_id">PK: wishlist_item_id (INT)</td></tr>
            <tr><td align="left" port="wishlist_id">FK: wishlist_id (INT)</td></tr>
            <tr><td align="left" port="product_id">FK: product_id (INT)</td></tr>
            <tr><td align="left">added_at (DATETIME)</td></tr>
        </table>
    >];
    
    // Define relationships with cardinality
    Customer:customer_id -> Order:customer_id [label="1:N", arrowhead="crow", dir="back"];
    Customer:customer_id -> Cart:customer_id [label="1:1", arrowhead="none", dir="both"];
    Customer:customer_id -> Wishlist:customer_id [label="1:1", arrowhead="none", dir="both"];
    
    Order:order_id -> Order_Item:order_id [label="1:N", arrowhead="crow", dir="back"];
    Order:order_id -> Payment:order_id [label="1:1", arrowhead="none", dir="both"];
    Order:order_id -> Shipment:order_id [label="1:1", arrowhead="none", dir="both"];
    
    Product:product_id -> Order_Item:product_id [label="1:N", arrowhead="crow", dir="back"];
    Product:product_id -> Cart_Item:product_id [label="1:N", arrowhead="crow", dir="back"];
    Product:product_id -> Wishlist_Item:product_id [label="1:N", arrowhead="crow", dir="back"];
    
    Category:category_id -> Product:category_id [label="1:N", arrowhead="crow", dir="back"];
    Category:category_id -> Category:parent_id [label="1:N", arrowhead="crow", dir="back", style="dashed"];
    
    Cart:cart_id -> Cart_Item:cart_id [label="1:N", arrowhead="crow", dir="back"];
    Wishlist:wishlist_id -> Wishlist_Item:wishlist_id [label="1:N", arrowhead="crow", dir="back"];
    
    // Layout hints
    {rank=same; Customer; Cart; Wishlist;}
    {rank=same; Order; Payment; Shipment;}
    {rank=same; Product; Category;}
    {rank=same; Order_Item; Cart_Item; Wishlist_Item;}
}
'''

# Write the DOT content to a file
with open('/home/ubuntu/ecommerce_er_model/er_diagram.dot', 'w') as f:
    f.write(dot_content)

# Generate the ER diagram in multiple formats
os.system('cd /home/ubuntu/ecommerce_er_model && dot -Tpng er_diagram.dot -o er_diagram.png')
os.system('cd /home/ubuntu/ecommerce_er_model && dot -Tsvg er_diagram.dot -o er_diagram.svg')
os.system('cd /home/ubuntu/ecommerce_er_model && dot -Tpdf er_diagram.dot -o er_diagram.pdf')

print("ER diagram generated successfully in PNG, SVG, and PDF formats.")
