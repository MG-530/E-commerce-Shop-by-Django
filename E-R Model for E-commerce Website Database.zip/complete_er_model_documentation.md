# E-Commerce Database: Complete E-R Model Documentation

This document provides a comprehensive description of the Entity-Relationship (E-R) model for an e-commerce database system. It integrates all the information gathered during the research and design process.

## 1. Introduction

An e-commerce database system requires a robust data model that can efficiently store and manage information about customers, products, orders, payments, shipments, and other related entities. This E-R model has been designed to support standard e-commerce functionality including:

- Customer account management
- Product catalog browsing and management
- Shopping cart functionality
- Wishlist management
- Order processing
- Payment handling
- Shipment tracking

The model follows database normalization principles up to the third normal form to ensure data integrity and minimize redundancy while supporting the transactional nature of e-commerce operations.

## 2. Core Entities Overview

The e-commerce database consists of the following core entities:

1. **Customer**: Represents users who create accounts to place orders
2. **Product**: Represents items available for purchase
3. **Category**: Represents the classification system for products
4. **Order**: Represents purchase transactions made by customers
5. **Order_Item**: Represents individual products within an order
6. **Payment**: Stores information about financial transactions
7. **Shipment**: Stores information about the delivery of orders
8. **Cart**: Represents the customer's temporary storage for products before purchase
9. **Cart_Item**: Junction entity connecting Cart and Product
10. **Wishlist**: Represents products that customers have saved for future consideration
11. **Wishlist_Item**: Junction entity connecting Wishlist and Product

## 3. Entity Descriptions with Attributes

### 3.1 Customer

The Customer entity stores information about registered users who can place orders on the e-commerce platform.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| customer_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each customer |
| first_name | VARCHAR(50) | NOT NULL | Customer's first name |
| last_name | VARCHAR(50) | NOT NULL | Customer's last name |
| email | VARCHAR(100) | NOT NULL, UNIQUE | Customer's email address, used for login |
| password | VARCHAR(255) | NOT NULL | Encrypted password for account security |
| address | VARCHAR(255) | | Customer's primary address |
| phone_number | VARCHAR(20) | | Customer's contact phone number |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.2 Product

The Product entity represents items that are available for purchase on the e-commerce platform.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| product_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each product |
| category_id | INT | FOREIGN KEY, NOT NULL | Reference to the product's category |
| SKU | VARCHAR(50) | NOT NULL, UNIQUE | Stock Keeping Unit, unique product code |
| name | VARCHAR(100) | NOT NULL | Product name |
| description | TEXT | | Detailed description of the product |
| price | DECIMAL(10,2) | NOT NULL | Current selling price of the product |
| stock | INT | NOT NULL, DEFAULT 0 | Current quantity available in inventory |
| image_url | VARCHAR(255) | | URL to the product's primary image |
| weight | DECIMAL(8,2) | | Product weight (in kg) |
| dimensions | VARCHAR(50) | | Product dimensions (LxWxH) |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Product creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.3 Category

The Category entity represents the classification system for products.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| category_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each category |
| name | VARCHAR(50) | NOT NULL, UNIQUE | Name of the category |
| description | VARCHAR(255) | | Description of the category |
| parent_id | INT | FOREIGN KEY | Reference to parent category (for hierarchical categories) |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Category creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.4 Order

The Order entity represents purchase transactions made by customers.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| order_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each order |
| customer_id | INT | FOREIGN KEY, NOT NULL | Reference to the customer who placed the order |
| order_date | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP | Date and time when the order was placed |
| total_price | DECIMAL(10,2) | NOT NULL | Total amount of the order |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Order status (pending, processing, shipped, delivered, cancelled) |
| shipping_address | VARCHAR(255) | NOT NULL | Address where the order will be shipped |
| billing_address | VARCHAR(255) | NOT NULL | Address for billing purposes |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.5 Order_Item

The Order_Item entity represents individual products within an order.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| order_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each order item |
| order_id | INT | FOREIGN KEY, NOT NULL | Reference to the parent order |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product ordered |
| quantity | INT | NOT NULL, DEFAULT 1 | Number of units of the product ordered |
| price | DECIMAL(10,2) | NOT NULL | Price of the product at the time of purchase |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order item creation timestamp |

### 3.6 Payment

The Payment entity stores information about financial transactions related to orders.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| payment_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each payment |
| order_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the order being paid for |
| payment_date | DATETIME | NOT NULL | Date and time when the payment was processed |
| payment_method | VARCHAR(50) | NOT NULL | Method used for payment (credit card, PayPal, etc.) |
| payment_status | VARCHAR(20) | NOT NULL | Status of the payment (pending, completed, failed, refunded) |
| amount | DECIMAL(10,2) | NOT NULL | Amount paid |
| transaction_id | VARCHAR(100) | UNIQUE | External payment processor's transaction ID |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Payment record creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.7 Shipment

The Shipment entity stores information about the delivery of orders.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| shipment_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each shipment |
| order_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the order being shipped |
| shipment_date | DATETIME | | Date and time when the order was shipped |
| carrier | VARCHAR(50) | | Shipping carrier (UPS, FedEx, etc.) |
| tracking_number | VARCHAR(100) | | Carrier's tracking number |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'processing' | Shipment status (processing, shipped, delivered) |
| address | VARCHAR(255) | NOT NULL | Shipping address |
| city | VARCHAR(50) | NOT NULL | City for shipping |
| state | VARCHAR(50) | NOT NULL | State/province for shipping |
| country | VARCHAR(50) | NOT NULL | Country for shipping |
| zip_code | VARCHAR(20) | NOT NULL | Postal/ZIP code for shipping |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Shipment record creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.8 Cart

The Cart entity represents the customer's temporary storage for products before purchase.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| cart_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each cart |
| customer_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the cart owner |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Cart creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.9 Cart_Item

The Cart_Item entity is a junction table that connects Cart and Product in a many-to-many relationship.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| cart_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each cart item |
| cart_id | INT | FOREIGN KEY, NOT NULL | Reference to the cart |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product |
| quantity | INT | NOT NULL, DEFAULT 1 | Number of units of the product in cart |
| added_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | When item was added to cart |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.10 Wishlist

The Wishlist entity represents products that customers have saved for future consideration.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| wishlist_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each wishlist |
| customer_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the wishlist owner |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Wishlist creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3.11 Wishlist_Item

The Wishlist_Item entity is a junction table that connects Wishlist and Product in a many-to-many relationship.

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| wishlist_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each wishlist item |
| wishlist_id | INT | FOREIGN KEY, NOT NULL | Reference to the wishlist |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product |
| added_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | When item was added to wishlist |

## 4. Entity Relationships

### 4.1 One-to-Many (1:N) Relationships

1. **Customer to Order (1:N)**
   - A customer can place multiple orders
   - Each order is placed by exactly one customer
   - Implementation: `customer_id` foreign key in Order table

2. **Order to Order_Item (1:N)**
   - An order can contain multiple order items
   - Each order item belongs to exactly one order
   - Implementation: `order_id` foreign key in Order_Item table

3. **Product to Order_Item (1:N)**
   - A product can appear in multiple order items
   - Each order item refers to exactly one product
   - Implementation: `product_id` foreign key in Order_Item table

4. **Category to Product (1:N)**
   - A category can contain multiple products
   - Each product belongs to exactly one category
   - Implementation: `category_id` foreign key in Product table

5. **Category to Category (1:N)**
   - A category can have multiple subcategories
   - Each subcategory has exactly one parent category
   - Implementation: `parent_id` self-referencing foreign key in Category table

### 4.2 One-to-One (1:1) Relationships

1. **Order to Payment (1:1)**
   - An order has exactly one payment
   - Each payment is associated with exactly one order
   - Implementation: `order_id` foreign key in Payment table with UNIQUE constraint

2. **Order to Shipment (1:1)**
   - An order has exactly one shipment
   - Each shipment is associated with exactly one order
   - Implementation: `order_id` foreign key in Shipment table with UNIQUE constraint

3. **Customer to Cart (1:1)**
   - A customer has exactly one shopping cart
   - Each cart belongs to exactly one customer
   - Implementation: `customer_id` foreign key in Cart table with UNIQUE constraint

4. **Customer to Wishlist (1:1)**
   - A customer has exactly one wishlist
   - Each wishlist belongs to exactly one customer
   - Implementation: `customer_id` foreign key in Wishlist table with UNIQUE constraint

### 4.3 Many-to-Many (M:N) Relationships

1. **Cart to Product (M:N)**
   - A cart can contain multiple products
   - A product can be in multiple carts
   - Implementation: Cart_Item junction table with foreign keys to both Cart and Product

2. **Wishlist to Product (M:N)**
   - A wishlist can contain multiple products
   - A product can be in multiple wishlists
   - Implementation: Wishlist_Item junction table with foreign keys to both Wishlist and Product

## 5. Database Constraints and Integrity Rules

### 5.1 Entity Integrity

- All tables have a primary key to uniquely identify each record
- Primary keys are defined as NOT NULL and AUTO_INCREMENT for automatic generation

### 5.2 Referential Integrity

- Foreign keys are used to maintain relationships between tables
- ON DELETE and ON UPDATE actions should be defined to maintain data consistency:
  - For most relationships: ON DELETE RESTRICT, ON UPDATE CASCADE
  - For dependent entities (e.g., Order_Item): ON DELETE CASCADE, ON UPDATE CASCADE

### 5.3 Domain Integrity

- Appropriate data types are assigned to each attribute
- Constraints like NOT NULL, UNIQUE, and DEFAULT values are applied where needed
- CHECK constraints can be used to enforce business rules (e.g., quantity > 0)

## 6. Indexing Strategy

For optimal performance, the following indexes are recommended:

1. **Customer**: Index on `email` for fast login lookups
2. **Product**: Indexes on `SKU` and `category_id` for fast product searches
3. **Order**: Indexes on `customer_id` and `status` for order filtering
4. **Order_Item**: Indexes on `order_id` and `product_id`
5. **Payment**: Index on `order_id` and `transaction_id`
6. **Shipment**: Index on `order_id` and `tracking_number`
7. **Cart_Item**: Composite index on `cart_id` and `product_id`
8. **Wishlist_Item**: Composite index on `wishlist_id` and `product_id`

## 7. Normalization

The database schema follows the Third Normal Form (3NF) to minimize redundancy and maintain data integrity:

- **First Normal Form (1NF)**: All attributes contain atomic values
- **Second Normal Form (2NF)**: All non-key attributes are fully dependent on the primary key
- **Third Normal Form (3NF)**: No transitive dependencies exist

## 8. Potential Extensions

The current E-R model can be extended to support additional e-commerce features:

1. **Product Reviews and Ratings**
   - Add a Review entity with foreign keys to Customer and Product
   - Include attributes for rating, comment text, and timestamps

2. **Discount and Promotion System**
   - Add Coupon and Discount entities
   - Create relationships with Product, Order, and Customer entities

3. **Inventory Management**
   - Add Warehouse and Inventory entities
   - Track product stock across multiple locations

4. **User Roles and Permissions**
   - Extend Customer entity to support different user roles
   - Add Permission entities for fine-grained access control

## 9. Conclusion

This E-R model provides a comprehensive foundation for an e-commerce database system. It supports all essential e-commerce functionality while maintaining data integrity and following database normalization principles. The model is designed to be scalable and can be extended to support additional features as needed.

The accompanying ER diagram visually represents all entities, attributes, and relationships described in this document.
