# Multi-Seller E-Commerce Platform: Updates to Existing Entities

This document details the necessary modifications to existing entities in the e-commerce database to support multi-seller functionality similar to Amazon's marketplace model.

## 1. Product Entity Updates

The Product entity requires significant updates to support multi-seller capabilities:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| seller_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller who offers this product |
| approval_status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Product approval status (pending, approved, rejected) |
| approval_date | DATETIME | NULL | When the product was approved by the platform |
| rejection_reason | TEXT | NULL | Reason for rejection if status is 'rejected' |
| commission_rate | DECIMAL(5,2) | NULL | Product-specific commission rate (overrides seller default) |
| is_featured | BOOLEAN | NOT NULL, DEFAULT false | Whether the product is featured on the platform |
| condition | VARCHAR(50) | NOT NULL, DEFAULT 'new' | Product condition (new, used, refurbished, etc.) |
| handling_time | INT | NOT NULL, DEFAULT 1 | Days needed to process before shipping |
| visibility | VARCHAR(20) | NOT NULL, DEFAULT 'visible' | Product visibility (visible, hidden, archived) |
| fulfillment_type | VARCHAR(50) | NOT NULL, DEFAULT 'seller' | How the product is fulfilled (seller, platform, dropship) |
| min_order_quantity | INT | NOT NULL, DEFAULT 1 | Minimum quantity per order |
| max_order_quantity | INT | NULL | Maximum quantity per order |
| is_approved_seller | BOOLEAN | NOT NULL, DEFAULT false | Whether seller is approved for this product category |
| seller_sku | VARCHAR(100) | NULL | Seller's own SKU for the product |
| manufacturer_part_number | VARCHAR(100) | NULL | Manufacturer's part number |
| gtin | VARCHAR(50) | NULL | Global Trade Item Number (UPC, EAN, etc.) |
| is_restricted | BOOLEAN | NOT NULL, DEFAULT false | Whether the product has selling restrictions |
| restriction_notes | TEXT | NULL | Notes about selling restrictions |

### Modified Attributes

| Attribute | Original | Updated | Description |
|-----------|----------|---------|-------------|
| SKU | UNIQUE | NOT UNIQUE | SKUs are now unique per seller, not platform-wide |
| price | Single price | Base price | Now represents the base price set by the seller |
| stock | Single value | Seller's stock | Now represents the seller's available inventory |

### New Indexes

- Index on `seller_id` for fast seller-based product lookups
- Composite index on `seller_id` and `approval_status` for filtering seller products by status
- Index on `is_featured` for featured product listings
- Index on `condition` for filtering by product condition
- Index on `visibility` for filtering visible products

## 2. Order Entity Updates

The Order entity needs modifications to support orders that may contain items from multiple sellers:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| is_multi_seller | BOOLEAN | NOT NULL, DEFAULT false | Whether the order contains items from multiple sellers |
| seller_count | INT | NOT NULL, DEFAULT 1 | Number of sellers involved in this order |
| platform_fee | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Platform's total fee for this order |
| platform_fee_percentage | DECIMAL(5,2) | NULL | Percentage used to calculate platform fee |
| total_commission | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Total commission charged to sellers |
| total_seller_amount | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Total amount to be paid to sellers |
| order_source | VARCHAR(50) | NOT NULL, DEFAULT 'website' | Source of the order (website, mobile app, etc.) |
| has_gift_options | BOOLEAN | NOT NULL, DEFAULT false | Whether the order includes gift options |
| gift_message | TEXT | NULL | Gift message if applicable |
| is_business_order | BOOLEAN | NOT NULL, DEFAULT false | Whether it's a business/wholesale order |
| business_name | VARCHAR(100) | NULL | Business name for business orders |
| tax_exempt_id | VARCHAR(50) | NULL | Tax exemption ID for business orders |
| platform_order_number | VARCHAR(50) | NOT NULL | Platform's customer-facing order number |

### New Indexes

- Index on `is_multi_seller` for filtering multi-seller orders
- Index on `seller_count` for analytics and reporting
- Index on `order_source` for tracking order channels
- Index on `is_business_order` for business order filtering

## 3. Order_Item Entity Updates

The Order_Item entity needs to link items to specific sellers and seller orders:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| seller_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller of this item |
| seller_order_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller-specific order |
| commission_rate | DECIMAL(5,2) | NOT NULL | Commission rate applied to this item |
| commission_amount | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Commission amount for this item |
| seller_amount | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Amount to be paid to the seller |
| item_status | VARCHAR(20) | NOT NULL, DEFAULT 'processing' | Status specific to this item (processing, shipped, etc.) |
| fulfillment_status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Fulfillment status of this item |
| tracking_number | VARCHAR(100) | NULL | Tracking number for this specific item |
| carrier | VARCHAR(50) | NULL | Shipping carrier for this item |
| estimated_delivery_date | DATETIME | NULL | Estimated delivery date for this item |
| actual_delivery_date | DATETIME | NULL | Actual delivery date for this item |
| is_gift | BOOLEAN | NOT NULL, DEFAULT false | Whether this item is a gift |
| gift_message | TEXT | NULL | Gift message specific to this item |
| seller_notes | TEXT | NULL | Seller's notes for this item |
| return_status | VARCHAR(20) | NULL | Return status if applicable |
| return_reason | TEXT | NULL | Reason for return if applicable |
| seller_sku | VARCHAR(100) | NULL | Seller's SKU for the product |

### New Indexes

- Index on `seller_id` for filtering items by seller
- Index on `seller_order_id` for linking to seller orders
- Index on `item_status` for filtering by status
- Index on `fulfillment_status` for fulfillment management
- Composite index on `seller_id` and `item_status` for seller-specific status filtering

## 4. User Entity Updates

The User entity needs updates to distinguish between different user roles:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| role | VARCHAR(20) | NOT NULL, DEFAULT 'customer' | User role (customer, seller, admin, etc.) |
| is_seller | BOOLEAN | NOT NULL, DEFAULT false | Whether the user is also a seller |
| seller_id | INT | FOREIGN KEY, NULL | Reference to Seller entity if user is a seller |
| account_status | VARCHAR(20) | NOT NULL, DEFAULT 'active' | Account status (active, suspended, etc.) |
| last_login_ip | VARCHAR(45) | NULL | IP address of last login |
| login_count | INT | NOT NULL, DEFAULT 0 | Number of times user has logged in |
| failed_login_attempts | INT | NOT NULL, DEFAULT 0 | Number of failed login attempts |
| account_locked_until | DATETIME | NULL | When account lock expires if locked |
| is_email_verified | BOOLEAN | NOT NULL, DEFAULT false | Whether email has been verified |
| is_phone_verified | BOOLEAN | NOT NULL, DEFAULT false | Whether phone has been verified |
| verification_token | VARCHAR(100) | NULL | Token for email/phone verification |
| password_reset_token | VARCHAR(100) | NULL | Token for password reset |
| password_reset_expires | DATETIME | NULL | Expiration of password reset token |
| tfa_enabled | BOOLEAN | NOT NULL, DEFAULT false | Whether two-factor authentication is enabled |
| tfa_secret | VARCHAR(100) | NULL | Secret for two-factor authentication |
| preferences | JSON | NULL | User preferences in JSON format |
| marketing_opt_in | BOOLEAN | NOT NULL, DEFAULT true | Whether user has opted in to marketing |
| referral_code | VARCHAR(50) | NULL | User's referral code |
| referred_by | INT | FOREIGN KEY, NULL | User ID who referred this user |

### New Indexes

- Index on `role` for filtering users by role
- Index on `is_seller` for quick identification of sellers
- Index on `seller_id` for linking to Seller entity
- Index on `account_status` for filtering by status
- Index on `is_email_verified` and `is_phone_verified` for verification filtering

## 5. Category Entity Updates

The Category entity needs updates to support seller category specialization:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| commission_rate | DECIMAL(5,2) | NOT NULL, DEFAULT 10.00 | Default commission rate for this category |
| requires_approval | BOOLEAN | NOT NULL, DEFAULT false | Whether products in this category require approval |
| is_restricted | BOOLEAN | NOT NULL, DEFAULT false | Whether the category has selling restrictions |
| restriction_notes | TEXT | NULL | Notes about selling restrictions |
| min_seller_rating | DECIMAL(3,2) | NULL | Minimum seller rating required to sell in this category |
| seller_count | INT | NOT NULL, DEFAULT 0 | Number of sellers active in this category |
| product_count | INT | NOT NULL, DEFAULT 0 | Number of products in this category |
| featured_sellers | JSON | NULL | List of featured seller IDs for this category |
| category_attributes | JSON | NULL | Required and optional attributes for products in this category |
| seo_title | VARCHAR(100) | NULL | SEO-optimized title for the category |
| seo_description | VARCHAR(255) | NULL | SEO-optimized description |
| seo_keywords | VARCHAR(255) | NULL | SEO keywords |

### New Indexes

- Index on `commission_rate` for commission calculations
- Index on `requires_approval` for product approval workflows
- Index on `is_restricted` for restricted category filtering
- Index on `seller_count` and `product_count` for analytics

## 6. Payment Entity Updates

The Payment entity needs updates to handle seller-specific payment processing:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| is_multi_seller | BOOLEAN | NOT NULL, DEFAULT false | Whether payment is for a multi-seller order |
| platform_fee | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Platform fee included in this payment |
| total_commission | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Total commission included in this payment |
| seller_payout_status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Status of seller payouts for this payment |
| payment_processor_fee | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Fee charged by payment processor |
| tax_collected | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Total tax collected with this payment |
| currency_conversion_rate | DECIMAL(10,6) | NULL | Currency conversion rate if applicable |
| original_currency | VARCHAR(3) | NULL | Original currency if converted |
| original_amount | DECIMAL(10,2) | NULL | Original amount in original currency |
| is_tax_exempt | BOOLEAN | NOT NULL, DEFAULT false | Whether the payment is tax exempt |
| tax_exemption_id | VARCHAR(50) | NULL | Tax exemption ID if applicable |

### New Indexes

- Index on `is_multi_seller` for filtering multi-seller payments
- Index on `seller_payout_status` for tracking payout status
- Index on `tax_collected` for tax reporting

## 7. Shipment Entity Updates

The Shipment entity needs updates to handle seller-specific shipping:

### New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| seller_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller responsible for this shipment |
| seller_order_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller-specific order |
| fulfillment_type | VARCHAR(50) | NOT NULL, DEFAULT 'seller' | How the shipment is fulfilled (seller, platform, dropship) |
| shipping_service | VARCHAR(100) | NULL | Specific shipping service used |
| shipping_cost | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Cost of shipping |
| shipping_label_url | VARCHAR(255) | NULL | URL to the shipping label |
| package_weight | DECIMAL(10,2) | NULL | Weight of the package in kg |
| package_dimensions | VARCHAR(50) | NULL | Dimensions of the package (LxWxH) |
| signature_required | BOOLEAN | NOT NULL, DEFAULT false | Whether signature is required for delivery |
| contains_restricted_items | BOOLEAN | NOT NULL, DEFAULT false | Whether shipment contains restricted items |
| customs_declaration_id | VARCHAR(100) | NULL | Customs declaration ID for international shipments |
| customs_value | DECIMAL(10,2) | NULL | Declared value for customs |
| customs_content_type | VARCHAR(50) | NULL | Content type for customs (merchandise, gift, etc.) |
| estimated_delivery_date | DATETIME | NULL | Estimated delivery date |
| actual_delivery_date | DATETIME | NULL | Actual delivery date |
| proof_of_delivery | VARCHAR(255) | NULL | URL to proof of delivery |
| return_label_url | VARCHAR(255) | NULL | URL to return shipping label if applicable |

### New Indexes

- Index on `seller_id` for filtering shipments by seller
- Index on `seller_order_id` for linking to seller orders
- Index on `fulfillment_type` for fulfillment management
- Index on `shipping_service` for shipping service analysis
- Index on `estimated_delivery_date` and `actual_delivery_date` for delivery tracking

## 8. Cart and Cart_Item Entity Updates

The Cart and Cart_Item entities need updates to handle multi-seller shopping carts:

### Cart New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| is_multi_seller | BOOLEAN | NOT NULL, DEFAULT false | Whether cart contains items from multiple sellers |
| seller_count | INT | NOT NULL, DEFAULT 0 | Number of distinct sellers in the cart |
| estimated_shipping | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Estimated total shipping cost |
| estimated_tax | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Estimated tax |
| coupon_code | VARCHAR(50) | NULL | Applied coupon code |
| discount_amount | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Total discount amount |
| gift_options | BOOLEAN | NOT NULL, DEFAULT false | Whether gift options are enabled |
| gift_message | TEXT | NULL | Gift message for the entire cart |
| saved_for_later_count | INT | NOT NULL, DEFAULT 0 | Number of items saved for later |

### Cart_Item New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| seller_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller of this item |
| is_in_stock | BOOLEAN | NOT NULL, DEFAULT true | Whether the item is currently in stock |
| estimated_shipping | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Estimated shipping for this item |
| estimated_tax | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Estimated tax for this item |
| item_discount | DECIMAL(10,2) | NOT NULL, DEFAULT 0.00 | Discount applied to this item |
| is_gift | BOOLEAN | NOT NULL, DEFAULT false | Whether this item is a gift |
| gift_message | TEXT | NULL | Gift message specific to this item |
| is_saved_for_later | BOOLEAN | NOT NULL, DEFAULT false | Whether item is saved for later |
| seller_note | VARCHAR(255) | NULL | Note to the seller |
| customization | TEXT | NULL | Product customization details |

### New Indexes

- Index on `is_multi_seller` and `seller_count` in Cart for multi-seller cart filtering
- Index on `seller_id` in Cart_Item for filtering items by seller
- Index on `is_saved_for_later` in Cart_Item for saved items filtering

## 9. Wishlist and Wishlist_Item Entity Updates

The Wishlist and Wishlist_Item entities need updates to track seller information:

### Wishlist_Item New Attributes

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| seller_id | INT | FOREIGN KEY, NOT NULL | Reference to the seller of this item |
| price_at_addition | DECIMAL(10,2) | NULL | Price when item was added to wishlist |
| current_price | DECIMAL(10,2) | NULL | Current price of the item |
| price_drop | BOOLEAN | NOT NULL, DEFAULT false | Whether price has dropped since addition |
| in_stock | BOOLEAN | NOT NULL, DEFAULT true | Whether the item is currently in stock |
| seller_name | VARCHAR(100) | NULL | Name of the seller at time of addition |
| seller_rating | DECIMAL(3,2) | NULL | Seller rating at time of addition |
| moved_to_cart | BOOLEAN | NOT NULL, DEFAULT false | Whether item was moved to cart |
| moved_to_cart_date | DATETIME | NULL | When item was moved to cart |
| priority | INT | NOT NULL, DEFAULT 0 | User-defined priority (1=highest) |
| notes | TEXT | NULL | User notes about this item |

### New Indexes

- Index on `seller_id` in Wishlist_Item for filtering by seller
- Index on `price_drop` for price drop notifications
- Index on `in_stock` for stock notifications
- Index on `priority` for sorting by priority

## Conclusion

These updates to existing entities transform a standard e-commerce database into a robust multi-seller marketplace platform similar to Amazon. The modifications support:

1. Seller-specific product listings and inventory management
2. Multi-seller orders and order processing
3. Seller-specific shipping and fulfillment
4. Commission and fee calculations
5. Enhanced security and user role management
6. Category-based seller specialization and restrictions
7. Improved shopping cart and wishlist functionality

These changes, combined with the new entities defined in previous documents, create a comprehensive database structure capable of supporting a sophisticated multi-seller e-commerce platform with all the features expected in a modern marketplace like Amazon.
