# Multi-Seller E-Commerce Platform: New Entities Identification

Based on the research of Amazon-like multi-seller marketplace models, this document identifies the new entities and modifications needed to transform a standard e-commerce database into a robust multi-seller platform.

## Core New Entities Required

### 1. Seller
The Seller entity is central to a multi-seller platform, representing merchants who sell products through the marketplace.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| seller_id | INT | Primary key, unique identifier for each seller |
| user_id | INT | Foreign key to User entity (sellers are users with special privileges) |
| company_name | VARCHAR(100) | Business or store name |
| description | TEXT | Detailed description of the seller's business |
| logo_url | VARCHAR(255) | URL to the seller's logo image |
| banner_url | VARCHAR(255) | URL to the seller's banner image |
| website_url | VARCHAR(255) | URL to the seller's external website (if any) |
| tax_id | VARCHAR(50) | Business tax identification number |
| registration_date | DATETIME | When the seller registered on the platform |
| status | VARCHAR(20) | Active, pending, suspended, etc. |
| commission_rate | DECIMAL(5,2) | Platform's commission percentage on sales |
| payout_method | VARCHAR(50) | Preferred payment method for receiving funds |
| payout_details | TEXT | Bank account or payment service details |
| is_featured | BOOLEAN | Whether the seller is featured on the platform |
| average_rating | DECIMAL(3,2) | Average of all seller ratings |
| total_ratings | INT | Total number of ratings received |
| total_sales | DECIMAL(12,2) | Total sales amount through the platform |
| last_login | DATETIME | Last time the seller logged in |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 2. Seller_Rating
This entity stores customer ratings and reviews specifically for sellers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| rating_id | INT | Primary key, unique identifier for each rating |
| seller_id | INT | Foreign key to Seller entity |
| customer_id | INT | Foreign key to Customer entity |
| order_id | INT | Foreign key to Order entity (optional) |
| rating | DECIMAL(3,2) | Numerical rating (e.g., 1-5) |
| review | TEXT | Textual review of the seller |
| communication_score | DECIMAL(3,2) | Rating for seller's communication |
| shipping_score | DECIMAL(3,2) | Rating for shipping speed and handling |
| accuracy_score | DECIMAL(3,2) | Rating for product accuracy |
| rating_date | DATETIME | When the rating was submitted |
| is_verified_purchase | BOOLEAN | Whether the rating is from a verified purchase |
| status | VARCHAR(20) | Published, pending, rejected |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 3. Seller_Payout
This entity tracks payments made from the platform to sellers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| payout_id | INT | Primary key, unique identifier for each payout |
| seller_id | INT | Foreign key to Seller entity |
| amount | DECIMAL(12,2) | Payout amount |
| currency | VARCHAR(3) | Currency code (USD, EUR, etc.) |
| status | VARCHAR(20) | Pending, processed, failed |
| payout_date | DATETIME | When the payout was processed |
| payout_method | VARCHAR(50) | Method used for the payout |
| transaction_id | VARCHAR(100) | External payment processor's transaction ID |
| payout_period_start | DATETIME | Start of the period covered by this payout |
| payout_period_end | DATETIME | End of the period covered by this payout |
| notes | TEXT | Additional information about the payout |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 4. Seller_Balance
This entity tracks the current balance and financial status of each seller.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| balance_id | INT | Primary key, unique identifier for each balance record |
| seller_id | INT | Foreign key to Seller entity |
| available_balance | DECIMAL(12,2) | Amount available for payout |
| pending_balance | DECIMAL(12,2) | Amount not yet available (in holding period) |
| currency | VARCHAR(3) | Currency code (USD, EUR, etc.) |
| last_payout_date | DATETIME | Date of the last payout |
| last_payout_amount | DECIMAL(12,2) | Amount of the last payout |
| total_earnings | DECIMAL(12,2) | Total earnings since joining |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 5. Seller_Order
This entity connects orders to specific sellers in a multi-seller order.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| seller_order_id | INT | Primary key, unique identifier for each seller order |
| order_id | INT | Foreign key to Order entity |
| seller_id | INT | Foreign key to Seller entity |
| subtotal | DECIMAL(10,2) | Subtotal for this seller's items in the order |
| shipping_fee | DECIMAL(10,2) | Shipping fee for this seller's items |
| tax | DECIMAL(10,2) | Tax for this seller's items |
| commission_amount | DECIMAL(10,2) | Platform commission on this seller's portion |
| seller_payout_amount | DECIMAL(10,2) | Amount to be paid to the seller |
| status | VARCHAR(20) | Processing, shipped, delivered, cancelled |
| tracking_number | VARCHAR(100) | Shipping tracking number |
| carrier | VARCHAR(50) | Shipping carrier |
| fulfillment_date | DATETIME | When the order was fulfilled |
| notes | TEXT | Additional information about the seller order |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 6. Seller_Category
This entity allows sellers to specialize in specific product categories.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| seller_category_id | INT | Primary key, unique identifier for each seller-category association |
| seller_id | INT | Foreign key to Seller entity |
| category_id | INT | Foreign key to Category entity |
| is_primary | BOOLEAN | Whether this is the seller's primary category |
| commission_rate | DECIMAL(5,2) | Category-specific commission rate (can override seller default) |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 7. Seller_Policy
This entity stores seller-specific policies.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| policy_id | INT | Primary key, unique identifier for each policy |
| seller_id | INT | Foreign key to Seller entity |
| policy_type | VARCHAR(50) | Return, shipping, warranty, etc. |
| policy_content | TEXT | Detailed policy content |
| is_active | BOOLEAN | Whether the policy is currently active |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 8. Seller_Message
This entity stores communication between buyers and sellers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| message_id | INT | Primary key, unique identifier for each message |
| seller_id | INT | Foreign key to Seller entity |
| customer_id | INT | Foreign key to Customer entity |
| order_id | INT | Foreign key to Order entity (optional) |
| product_id | INT | Foreign key to Product entity (optional) |
| message | TEXT | Message content |
| is_from_seller | BOOLEAN | Whether the message is from the seller (vs. customer) |
| is_read | BOOLEAN | Whether the message has been read by the recipient |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 9. Seller_Notification
This entity stores notifications for sellers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| notification_id | INT | Primary key, unique identifier for each notification |
| seller_id | INT | Foreign key to Seller entity |
| type | VARCHAR(50) | Order, message, payout, etc. |
| title | VARCHAR(255) | Notification title |
| content | TEXT | Notification content |
| reference_id | INT | ID of the related entity (order_id, message_id, etc.) |
| is_read | BOOLEAN | Whether the notification has been read |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

### 10. Seller_Analytics
This entity stores analytics data for sellers.

| Attribute | Data Type | Description |
|-----------|-----------|-------------|
| analytics_id | INT | Primary key, unique identifier for each analytics record |
| seller_id | INT | Foreign key to Seller entity |
| date | DATE | Date of the analytics data |
| views | INT | Number of store/product views |
| visitors | INT | Number of unique visitors |
| orders | INT | Number of orders received |
| revenue | DECIMAL(12,2) | Total revenue for the day |
| conversion_rate | DECIMAL(5,2) | Percentage of visitors who made a purchase |
| average_order_value | DECIMAL(10,2) | Average value of orders |
| created_at | DATETIME | Record creation timestamp |
| updated_at | DATETIME | Last update timestamp |

## Modifications to Existing Entities

### 1. Product Entity
The Product entity needs to be modified to include seller information:

| New Attribute | Data Type | Description |
|---------------|-----------|-------------|
| seller_id | INT | Foreign key to Seller entity |
| approval_status | VARCHAR(20) | Pending, approved, rejected |
| approval_date | DATETIME | When the product was approved |
| commission_rate | DECIMAL(5,2) | Product-specific commission rate (can override seller default) |
| is_featured | BOOLEAN | Whether the product is featured on the platform |
| condition | VARCHAR(50) | New, used, refurbished, etc. |
| handling_time | INT | Days needed to process before shipping |

### 2. Order Entity
The Order entity needs modifications to support multi-seller orders:

| New Attribute | Data Type | Description |
|---------------|-----------|-------------|
| is_multi_seller | BOOLEAN | Whether the order contains items from multiple sellers |
| seller_count | INT | Number of sellers involved in this order |
| platform_fee | DECIMAL(10,2) | Platform's total fee for this order |

### 3. Order_Item Entity
The Order_Item entity needs to link to sellers:

| New Attribute | Data Type | Description |
|---------------|-----------|-------------|
| seller_id | INT | Foreign key to Seller entity |
| seller_order_id | INT | Foreign key to Seller_Order entity |
| commission_rate | DECIMAL(5,2) | Commission rate applied to this item |
| commission_amount | DECIMAL(10,2) | Commission amount for this item |

### 4. User Entity
The User entity needs a role field to distinguish between customers and sellers:

| New Attribute | Data Type | Description |
|---------------|-----------|-------------|
| role | VARCHAR(20) | Customer, seller, admin, etc. |
| is_seller | BOOLEAN | Whether the user is also a seller |

## Conclusion

These new entities and modifications will transform a standard e-commerce database into a robust multi-seller marketplace platform similar to Amazon. The design supports:

1. Seller registration and management
2. Seller-specific product listings
3. Seller ratings and reviews
4. Financial operations (commissions, payouts)
5. Order management across multiple sellers
6. Seller-customer communication
7. Seller analytics and reporting

In the next phase, we will define detailed relationships between these entities and update the existing E-R diagram to incorporate these changes.
