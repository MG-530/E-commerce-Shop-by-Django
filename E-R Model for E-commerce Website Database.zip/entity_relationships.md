# E-Commerce Database: Entity Relationships

This document identifies and describes the relationships between core entities in an e-commerce database system.

## Relationship Types

In the Entity-Relationship model, relationships between entities can be categorized as:

1. **One-to-One (1:1)**: One entity instance relates to exactly one instance of another entity
2. **One-to-Many (1:N)**: One entity instance relates to multiple instances of another entity
3. **Many-to-Many (M:N)**: Multiple instances of an entity relate to multiple instances of another entity

## Core Entity Relationships

### 1. Customer and Order (1:N)
- A customer can place multiple orders
- Each order is placed by exactly one customer
- Relationship: One-to-Many
- Cardinality: 1:N
- Foreign Key: `customer_id` in Order table references Customer

### 2. Order and Order_Item (1:N)
- An order can contain multiple order items
- Each order item belongs to exactly one order
- Relationship: One-to-Many
- Cardinality: 1:N
- Foreign Key: `order_id` in Order_Item table references Order
- Order_Item is a dependent entity of Order (existence dependency)

### 3. Product and Order_Item (1:N)
- A product can appear in multiple order items
- Each order item refers to exactly one product
- Relationship: One-to-Many
- Cardinality: 1:N
- Foreign Key: `product_id` in Order_Item table references Product

### 4. Category and Product (1:N)
- A category can contain multiple products
- Each product belongs to exactly one category
- Relationship: One-to-Many
- Cardinality: 1:N
- Foreign Key: `category_id` in Product table references Category

### 5. Order and Payment (1:1)
- An order has exactly one payment
- Each payment is associated with exactly one order
- Relationship: One-to-One
- Cardinality: 1:1
- Foreign Key: `order_id` in Payment table references Order

### 6. Order and Shipment (1:1)
- An order has exactly one shipment
- Each shipment is associated with exactly one order
- Relationship: One-to-One
- Cardinality: 1:1
- Foreign Key: `order_id` in Shipment table references Order

### 7. Customer and Cart (1:1)
- A customer has exactly one shopping cart
- Each cart belongs to exactly one customer
- Relationship: One-to-One
- Cardinality: 1:1
- Foreign Key: `customer_id` in Cart table references Customer
- Cart is a dependent entity of Customer (existence dependency)

### 8. Cart and Product (M:N)
- A cart can contain multiple products
- A product can be in multiple carts
- Relationship: Many-to-Many
- Cardinality: M:N
- Implementation: Requires a junction table (Cart_Item) with foreign keys to both Cart and Product
- Additional attributes: `quantity`

### 9. Customer and Wishlist (1:1)
- A customer has exactly one wishlist
- Each wishlist belongs to exactly one customer
- Relationship: One-to-One
- Cardinality: 1:1
- Foreign Key: `customer_id` in Wishlist table references Customer
- Wishlist is a dependent entity of Customer (existence dependency)

### 10. Wishlist and Product (M:N)
- A wishlist can contain multiple products
- A product can be in multiple wishlists
- Relationship: Many-to-Many
- Cardinality: M:N
- Implementation: Requires a junction table (Wishlist_Item) with foreign keys to both Wishlist and Product

## Relationship Diagram Summary

```
Customer (1) --- (N) Order (1) --- (N) Order_Item (N) --- (1) Product (N) --- (1) Category
                   |                                        |
                   |                                        |
                   v                                        v
                Payment (1)                          Cart_Item (Junction)
                   |                                        |
                   |                                        |
                   v                                        v
                Shipment                             Wishlist_Item (Junction)
                                                           |
                                                           |
                                                           v
                                                        Wishlist
```

This diagram illustrates the key relationships between entities in the e-commerce database system. The relationships ensure data integrity and proper functioning of the e-commerce platform, allowing customers to browse products, add them to carts or wishlists, place orders, and track shipments.
