# E-Commerce Database: Primary Keys and Variable Types

This document provides detailed information about primary keys, foreign keys, and precise variable types for all entities in the e-commerce database model.

## Data Type Standards

For consistency across the database, the following data type standards are used:

- **Integer**: Used for IDs, counts, and numeric values without decimal points
- **Decimal/Numeric**: Used for monetary values and prices (typically DECIMAL(10,2) for currency)
- **VARCHAR/String**: Used for text data with variable length
- **CHAR**: Used for fixed-length text data
- **DATE/DATETIME**: Used for date and timestamp values
- **BOOLEAN**: Used for true/false flags
- **TEXT**: Used for long descriptions or content

## Entity Primary Keys and Attributes

### 1. Customer

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| customer_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each customer |
| first_name | VARCHAR(50) | NOT NULL | Customer's first name |
| last_name | VARCHAR(50) | NOT NULL | Customer's last name |
| email | VARCHAR(100) | NOT NULL, UNIQUE | Customer's email address, used for login |
| password | VARCHAR(255) | NOT NULL | Encrypted password for account security |
| address | VARCHAR(255) | | Customer's primary address |
| phone_number | VARCHAR(20) | | Customer's contact phone number |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 2. Product

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| product_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each product |
| category_id | INT | FOREIGN KEY, NOT NULL | Reference to the product's category |
| SKU | VARCHAR(50) | NOT NULL, UNIQUE | Stock Keeping Unit, unique product code |
| name | VARCHAR(100) | NOT NULL | Product name |
| description | TEXT | | Detailed description of the product |
| price | DECIMAL(10,2) | NOT NULL | Current selling price of the product |
| stock | INT | NOT NULL, DEFAULT 0 | Current quantity available in inventory |
| image_url | VARCHAR(255) | | URL to the product's primary image |
| weight | DECIMAL(8,2) | | Product weight (in kg) |
| dimensions | VARCHAR(50) | | Product dimensions (LxWxH) |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Product creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 3. Category

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| category_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each category |
| name | VARCHAR(50) | NOT NULL, UNIQUE | Name of the category |
| description | VARCHAR(255) | | Description of the category |
| parent_id | INT | FOREIGN KEY | Reference to parent category (for hierarchical categories) |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Category creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 4. Order

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| order_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each order |
| customer_id | INT | FOREIGN KEY, NOT NULL | Reference to the customer who placed the order |
| order_date | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP | Date and time when the order was placed |
| total_price | DECIMAL(10,2) | NOT NULL | Total amount of the order |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Order status (pending, processing, shipped, delivered, cancelled) |
| shipping_address | VARCHAR(255) | NOT NULL | Address where the order will be shipped |
| billing_address | VARCHAR(255) | NOT NULL | Address for billing purposes |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 5. Order_Item

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| order_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each order item |
| order_id | INT | FOREIGN KEY, NOT NULL | Reference to the parent order |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product ordered |
| quantity | INT | NOT NULL, DEFAULT 1 | Number of units of the product ordered |
| price | DECIMAL(10,2) | NOT NULL | Price of the product at the time of purchase |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order item creation timestamp |

### 6. Payment

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| payment_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each payment |
| order_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the order being paid for |
| payment_date | DATETIME | NOT NULL | Date and time when the payment was processed |
| payment_method | VARCHAR(50) | NOT NULL | Method used for payment (credit card, PayPal, etc.) |
| payment_status | VARCHAR(20) | NOT NULL | Status of the payment (pending, completed, failed, refunded) |
| amount | DECIMAL(10,2) | NOT NULL | Amount paid |
| transaction_id | VARCHAR(100) | UNIQUE | External payment processor's transaction ID |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Payment record creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 7. Shipment

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| shipment_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each shipment |
| order_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the order being shipped |
| shipment_date | DATETIME | | Date and time when the order was shipped |
| carrier | VARCHAR(50) | | Shipping carrier (UPS, FedEx, etc.) |
| tracking_number | VARCHAR(100) | | Carrier's tracking number |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'processing' | Shipment status (processing, shipped, delivered) |
| address | VARCHAR(255) | NOT NULL | Shipping address |
| city | VARCHAR(50) | NOT NULL | City for shipping |
| state | VARCHAR(50) | NOT NULL | State/province for shipping |
| country | VARCHAR(50) | NOT NULL | Country for shipping |
| zip_code | VARCHAR(20) | NOT NULL | Postal/ZIP code for shipping |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Shipment record creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 8. Cart

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| cart_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each cart |
| customer_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the cart owner |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Cart creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 9. Cart_Item (Junction table for Cart-Product M:N relationship)

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| cart_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each cart item |
| cart_id | INT | FOREIGN KEY, NOT NULL | Reference to the cart |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product |
| quantity | INT | NOT NULL, DEFAULT 1 | Number of units of the product in cart |
| added_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | When item was added to cart |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 10. Wishlist

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| wishlist_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each wishlist |
| customer_id | INT | FOREIGN KEY, NOT NULL, UNIQUE | Reference to the wishlist owner |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Wishlist creation timestamp |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### 11. Wishlist_Item (Junction table for Wishlist-Product M:N relationship)

| Attribute | Data Type | Constraints | Description |
|-----------|-----------|-------------|-------------|
| wishlist_item_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each wishlist item |
| wishlist_id | INT | FOREIGN KEY, NOT NULL | Reference to the wishlist |
| product_id | INT | FOREIGN KEY, NOT NULL | Reference to the product |
| added_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | When item was added to wishlist |

## Foreign Key Relationships

1. **Product** → **Category**: `category_id` in Product references `category_id` in Category
2. **Category** → **Category**: `parent_id` in Category references `category_id` in Category (self-reference)
3. **Order** → **Customer**: `customer_id` in Order references `customer_id` in Customer
4. **Order_Item** → **Order**: `order_id` in Order_Item references `order_id` in Order
5. **Order_Item** → **Product**: `product_id` in Order_Item references `product_id` in Product
6. **Payment** → **Order**: `order_id` in Payment references `order_id` in Order
7. **Shipment** → **Order**: `order_id` in Shipment references `order_id` in Order
8. **Cart** → **Customer**: `customer_id` in Cart references `customer_id` in Customer
9. **Cart_Item** → **Cart**: `cart_id` in Cart_Item references `cart_id` in Cart
10. **Cart_Item** → **Product**: `product_id` in Cart_Item references `product_id` in Product
11. **Wishlist** → **Customer**: `customer_id` in Wishlist references `customer_id` in Customer
12. **Wishlist_Item** → **Wishlist**: `wishlist_id` in Wishlist_Item references `wishlist_id` in Wishlist
13. **Wishlist_Item** → **Product**: `product_id` in Wishlist_Item references `product_id` in Product

## Indexing Recommendations

For optimal performance, the following indexes are recommended:

1. **Customer**: Index on `email` for fast login lookups
2. **Product**: Indexes on `SKU` and `category_id` for fast product searches
3. **Order**: Indexes on `customer_id` and `status` for order filtering
4. **Order_Item**: Indexes on `order_id` and `product_id`
5. **Payment**: Index on `order_id` and `transaction_id`
6. **Shipment**: Index on `order_id` and `tracking_number`
7. **Cart_Item**: Composite index on `cart_id` and `product_id`
8. **Wishlist_Item**: Composite index on `wishlist_id` and `product_id`

This detailed specification of primary keys, foreign keys, and variable types ensures data integrity, optimizes storage, and facilitates efficient querying of the e-commerce database.
